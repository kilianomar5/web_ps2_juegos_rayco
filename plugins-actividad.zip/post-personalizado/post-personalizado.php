<?php
/*
    Plugin Name: Post Personalizado
    Description: Crear un post type personalizado para Videojuegos
    Version: 1.0.1
    Author: Kilian
    Text Domain: noticias_kilian
*/

if (!defined('ABSPATH')) die();

// Registrar post type Videojuegos
function noticias_kilian_videojuegos_post_type() {

    $labels = array(
        'name'                  => _x('Videojuegos', 'Post Type General Name', 'noticias_kilian'),
        'singular_name'         => _x('Videojuego', 'Post Type Singular Name', 'noticias_kilian'),
        'menu_name'             => __('Videojuegos', 'noticias_kilian'),
        'name_admin_bar'        => __('Videojuegos', 'noticias_kilian'),
        'archives'              => __('Archivo', 'noticias_kilian'),
        'attributes'            => __('Atributos', 'noticias_kilian'),
        'parent_item_colon'     => __('Videojuego Padre', 'noticias_kilian'),
        'all_items'             => __('Todos los Videojuegos', 'noticias_kilian'),
        'add_new_item'          => __('Agregar Videojuego', 'noticias_kilian'),
        'add_new'               => __('Agregar Videojuego', 'noticias_kilian'),
        'new_item'              => __('Nuevo Videojuego', 'noticias_kilian'),
        'edit_item'             => __('Editar Videojuego', 'noticias_kilian'),
        'update_item'           => __('Actualizar Videojuego', 'noticias_kilian'),
        'view_item'             => __('Ver Videojuego', 'noticias_kilian'),
        'view_items'            => __('Ver Videojuegos', 'noticias_kilian'),
        'search_items'          => __('Buscar Videojuego', 'noticias_kilian'),
        'not_found'             => __('No Encontrado', 'noticias_kilian'),
        'not_found_in_trash'    => __('No Encontrado en Papelera', 'noticias_kilian'),
        'featured_image'        => __('Imagen Destacada', 'noticias_kilian'),
        'set_featured_image'    => __('Guardar Imagen Destacada', 'noticias_kilian'),
        'remove_featured_image' => __('Eliminar Imagen Destacada', 'noticias_kilian'),
        'use_featured_image'    => __('Utilizar como Imagen Destacada', 'noticias_kilian'),
        'insert_into_item'      => __('Insertar en Videojuego', 'noticias_kilian'),
        'uploaded_to_this_item' => __('Agregado en Videojuego', 'noticias_kilian'),
        'items_list'            => __('Lista de Videojuegos', 'noticias_kilian'),
        'items_list_navigation' => __('Navegación de Videojuegos', 'noticias_kilian'),
        'filter_items_list'     => __('Filtrar Videojuegos', 'noticias_kilian'),
    );

    $args = array(
        'label'                 => __('Videojuegos', 'noticias_kilian'),
        'description'           => __('Videojuegos para el sitio web', 'noticias_kilian'),
        'labels'                => $labels,
        'supports'              => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'hierarchical'          => false, 
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 4,
        'menu_icon'             => 'dashicons-welcome-learn-more',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
    );

    register_post_type('videojuegos', $args);
}

add_action('init', 'noticias_kilian_videojuegos_post_type', 0);
